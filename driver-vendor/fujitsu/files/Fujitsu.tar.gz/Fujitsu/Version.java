// Javaバージョン判定プログラム
public class Version {

	public static void main(String args[]) {

		// 第一引数に必要なjava版数("1.5"など)を指定する。
		if (args.length > 0) {
			
			// '.'で区切られたバージョン文字列の数字をそれぞれ比較する。
			String[] argVer = args[0].split("\\.", 0);
			String[] javaVer = System.getProperty("java.specification.version").split("\\.", 0);

			for (int i = 0 ; (i < argVer.length) && (i < javaVer.length) ; i++) {

				if (Integer.parseInt(argVer[i]) > Integer.parseInt(javaVer[i])) {
					// このJavaVMは古い
					System.exit(1);
				}
			}
		}
		// このJavaVMは要件を満たしている
		System.exit(0);
	}
}
