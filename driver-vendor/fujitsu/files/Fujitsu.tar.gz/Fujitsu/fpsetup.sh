
#!/bin/bash

#
# Test JavaVM version
#
javac -encoding UTF-8 Version.java
java -classpath . Version 1.5

case $? in
    # Version 1.5 or later
	0) cp -f Setup.java1.5.txt Setup.java;;

    # Version 1.4 or earlier
	*) cp -f Setup.java1.4.txt Setup.java;;
esac

chmod 777 Setup.java
javac -encoding UTF-8 Setup.java
java -classpath . Setup
