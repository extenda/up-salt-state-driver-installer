#!/bin/sh
#
# JavaPOS tester script for FP Printer.
#
# Copyright(C) 2017 FUJITSU ISOTEC LIMITED.
#

case "$1" in 
	"USB" )    IF_NAME=USB ;;
	"Serial" ) IF_NAME=SER ;;
esac

case "$2" in
	"FP-510II" )  PR_NAME=FP510II ;;
esac

LOG_DEV_NAME=${PR_NAME}${IF_NAME}PRT

case "$LOG_DEV_NAME" in
	"FP510IIUSBPRT" ) ;;
	"FP510IISERPRT" ) ;;
	*)  exit 1 ;;
esac

#
# JavaPOS test print
#
javac -encoding UTF-8 HelloWorld_Test.java
java -classpath . HelloWorld_Test $LOG_DEV_NAME

