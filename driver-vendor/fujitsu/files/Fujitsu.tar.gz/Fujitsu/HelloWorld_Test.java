import jpos.POSPrinter;
import jpos.POSPrinterConst;
import jpos.JposException;

public class HelloWorld_Test {

	public static void main(String[] args) {
		POSPrinter posprinter1;
		int i;

		if (args.length == 0) {
			System.out.println("\nPlease specify a logical device name. \n\n");
			System.out.println("USAGE:\n\n");
			System.out.println("    > java HelloWorld_Test LOGICAL_DEVICE_NAME\n\n"	);
			return ;
		}

		System.out.println("Hello World!!\n");
		
		posprinter1 = new POSPrinter();
		
		try {
			posprinter1.open(args[0]);
			posprinter1.claim(10000);
			posprinter1.setDeviceEnabled(true);
			posprinter1.setCharacterSet(998);
			posprinter1.transactionPrint(POSPrinterConst.PTR_S_RECEIPT, POSPrinterConst.PTR_TP_TRANSACTION);
			posprinter1.printNormal(POSPrinterConst.PTR_S_RECEIPT,"Hello World!!\n\n\n\n");
			for(i=0; i<posprinter1.getRecLinesToPaperCut(); i++) {
				posprinter1.printNormal(POSPrinterConst.PTR_S_RECEIPT,"\n");
			}
			posprinter1.cutPaper(100);
			posprinter1.transactionPrint(POSPrinterConst.PTR_S_RECEIPT, POSPrinterConst.PTR_TP_NORMAL);
			posprinter1.setDeviceEnabled(false);
			posprinter1.release();
			posprinter1.close();
		}
		catch  (JposException e) {
			System.out.println(e.getMessage());	
		}
	}
}
